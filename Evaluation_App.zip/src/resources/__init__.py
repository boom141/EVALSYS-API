from src.resources.controllers.evaluation_controller import *
from src.resources.controllers.admin_controller import *
from src.resources.controllers.auth_controller import *
from src.resources.controllers.student_controller import *
from src.resources.controllers.forms_controller import *